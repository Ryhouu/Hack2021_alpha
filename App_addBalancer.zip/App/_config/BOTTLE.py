name = "whc's bottle"

# p_add_mem = 0.35
# p_minus_mem = 0.35
pBomb = 10
pChamber = 8
