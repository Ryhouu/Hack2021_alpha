default_speed = 1
default_vision = 1
default_memory = 5
default_identity = "Human"