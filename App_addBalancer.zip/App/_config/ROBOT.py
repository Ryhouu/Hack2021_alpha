default_speed = 2
default_vision = 2
default_memory = 0
default_identity = "Robot"