import sys
sys.path.append(".")


import os

print (os.getcwd())
# from Frame.Player import Player

# from Service import InitMaze as im
# im.run()

from Session import Sess
Sess.run()

