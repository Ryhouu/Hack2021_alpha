class Component (object) :
    attr = ""
    img = ""
    def __init__(self) -> None:
        super().__init__()